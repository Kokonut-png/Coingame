
const allCards = [
  { id: 1, name: "Aqualynx", type: "Water", rarity: "gewoon", img: "img/water1.png" },
  { id: 2, name: "Pyrosaur", type: "Vuur", rarity: "gewoon", img: "img/fire1.png" },
  { id: 3, name: "Sylvabeetle", type: "Natuur", rarity: "zeldzaam", img: "img/nature1.png" },
  { id: 4, name: "Emberdrake", type: "Vuur", rarity: "episch", img: "img/fire2.png" },
  { id: 5, name: "Floravern", type: "Natuur", rarity: "legendarisch", img: "img/nature2.png" },
  { id: 6, name: "Tidelord", type: "Water", rarity: "zeldzaam", img: "img/water2.png" },
];
