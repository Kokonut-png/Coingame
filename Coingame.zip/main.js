
let money = 150;
let collection = [];

const rarityChances = {
  "gewoon": 0.5,
  "zeldzaam": 0.3,
  "episch": 0.15,
  "legendarisch": 0.05
};

const valueRanges = {
  "gewoon": [5, 10],
  "zeldzaam": [15, 25],
  "episch": [30, 50],
  "legendarisch": [60, 100]
};

document.getElementById("money").innerText = `Saldo: $${money}`;
document.getElementById("buy-pack").addEventListener("click", buyPack);

function buyPack() {
  if (money < 50) return alert("Niet genoeg geld!");
  money -= 50;
  updateMoney();

  const pack = [];
  for (let i = 0; i < 3; i++) {
    const card = drawCard();
    pack.push(card);
    collection.push(card);
  }

  renderPack(pack);
  renderCollection();
}

function drawCard() {
  let r = Math.random();
  let total = 0;
  for (let rarity in rarityChances) {
    total += rarityChances[rarity];
    if (r <= total) {
      let pool = allCards.filter(c => c.rarity === rarity);
      return pool[Math.floor(Math.random() * pool.length)];
    }
  }
}

function renderPack(pack) {
  const container = document.getElementById("pack-result");
  container.innerHTML = "";
  pack.forEach(card => {
    const div = document.createElement("div");
    div.className = "card";
    div.innerHTML = `
      <img src="${card.img}" alt="${card.name}">
      <strong>${card.name}</strong><br>
      <em>${card.type} - ${card.rarity}</em>
    `;
    container.appendChild(div);
  });
}

function renderCollection() {
  const container = document.getElementById("collection");
  container.innerHTML = "";
  collection.forEach((card, index) => {
    const div = document.createElement("div");
    div.className = "card";
    div.innerHTML = `
      <img src="${card.img}" alt="${card.name}">
      <strong>${card.name}</strong><br>
      <em>${card.type} - ${card.rarity}</em><br>
      <button onclick="sellCard(${index})">Verkopen</button>
    `;
    container.appendChild(div);
  });
}

function sellCard(index) {
  const card = collection[index];
  const [min, max] = valueRanges[card.rarity];
  const value = Math.floor(Math.random() * (max - min + 1)) + min;
  money += value;
  collection.splice(index, 1);
  updateMoney();
  renderCollection();
}

function updateMoney() {
  document.getElementById("money").innerText = `Saldo: $${money}`;
}
